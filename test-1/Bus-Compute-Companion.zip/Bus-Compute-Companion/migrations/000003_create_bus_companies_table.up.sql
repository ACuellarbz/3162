CREATE TABLE IF NOT EXISTS bus_companies (
  id bigserial PRIMARY KEY,
  company_name varchar(255)
);