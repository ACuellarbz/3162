INSERT INTO bus_companies(id, company_name)
VALUES
(01, 'James'),
(02, 'McFadzean'),
(03, 'Westline'),
(04, 'Floralia'),
(05, 'Morales'),
(06, 'Shaws'),
(07, 'Russel'),
(08, 'Brads'),
(09, 'Speed Busline');