CREATE TABLE IF NOT EXISTS locations_of_stop (
  id bigserial PRIMARY KEY,
  stops varchar(255) --Possible name change
);