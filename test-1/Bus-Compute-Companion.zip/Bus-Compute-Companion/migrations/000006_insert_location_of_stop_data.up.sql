INSERT INTO locations_of_stop(id, stops)
VALUES
(001, 'Belize'),
(002, 'Belmopan'),
(003, 'Cayo'),
(004, 'Punta Gorda'),
(005, 'Dangriga'),
(006, 'Stann Creek'),
(007, 'Corozal'),
(008, 'Orange Walk');