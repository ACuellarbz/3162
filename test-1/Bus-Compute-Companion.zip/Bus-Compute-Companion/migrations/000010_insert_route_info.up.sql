INSERT INTO routes(id, route_name, number_of_miles, total_cost, number_of_tickets_available)
VALUES
(1, 1, 50, 25, 50),
(2, 2, 75, 25, 50),
(3, 3, 110, 25, 50),
(4, 4, 15, 25, 50),
(5, 5, 25, 25, 50),
(6, 6, 45, 25, 50),
(7, 7, 65, 25, 50),
(8, 8, 70, 25, 50);

